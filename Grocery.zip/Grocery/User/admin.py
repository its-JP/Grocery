from django.contrib import admin
from .models import GroceryItem

# Register your models here.

admin.site.register(GroceryItem)